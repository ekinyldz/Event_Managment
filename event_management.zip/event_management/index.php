<?php
require_once 'classes/Database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Management System</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to Event Management System</h1>
        <a href="register.php">Register</a> | <a href="login.php">Login</a>
    </div>
</body>
</html>
